#!/usr/bin/env bash
# Publish panel tarball + installer scripts to nexlify.live (run on vendor VPS).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "Building panel tarball (isolated staging copy)..."
STAGE="$(mktemp -d /tmp/nexlify-publish-XXXXXX)"
cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

if command -v rsync >/dev/null 2>&1; then
  rsync -a \
    --exclude=node_modules --exclude=.next --exclude=.git \
    --exclude=data --exclude=dist --exclude='.env*' \
    "$ROOT/" "$STAGE/"
else
  cp -a "$ROOT" "$STAGE/src-root" 2>/dev/null || cp -a "$ROOT/." "$STAGE/"
fi

cd "$STAGE"
sed -i 's/\r$//' scripts/build-panel-download.sh scripts/publish-panel-release.sh 2>/dev/null || true
npm run package:panel
TAR="$STAGE/dist/nexlify-panel.tar.gz"
[ -f "$TAR" ] || { echo "Missing $TAR" >&2; exit 1; }

DEST="${PANEL_PUBLISH_DEST:-/var/www/nexlify/public/downloads/nexlify-panel.tar.gz}"
INSTALL_DEST="${PANEL_INSTALL_DEST:-/var/www/nexlify/public/install}"

mkdir -p "$(dirname "$DEST")" "$INSTALL_DEST"
cp -f "$TAR" "$DEST"
cp -f "$ROOT/scripts/install-linux.sh" "$INSTALL_DEST/panel.sh"
cp -f "$ROOT/scripts/fix-panel-auto-update.sh" "$INSTALL_DEST/fix-panel-auto-update.sh"
cp -f "$ROOT/scripts/fix-panel-restart.sh" "$INSTALL_DEST/fix-panel-restart.sh"
mkdir -p "$INSTALL_DEST/scripts"
cp -f "$ROOT/scripts/panel-restart-safe.sh" "$INSTALL_DEST/scripts/panel-restart-safe.sh"
cp -f "$ROOT/scripts/apply-panel-fast-update.sh" "$INSTALL_DEST/apply-panel-fast-update.sh"
sed -i 's/\r$//' "$INSTALL_DEST"/*.sh 2>/dev/null || true
chmod +x "$INSTALL_DEST"/*.sh

echo "Published:"
echo "  $DEST ($(du -h "$DEST" | cut -f1))"
echo "  $INSTALL_DEST/panel.sh"
echo "  $INSTALL_DEST/fix-panel-auto-update.sh"
echo "Release feed: sync panel-releases.json to marketing and redeploy nexlify-web."