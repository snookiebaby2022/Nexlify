import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  // Mock load balancer data; replace with real connection/bandwidth aggregation
  const data = [
    { id: "srv-1", name: "Main Server", connections: 342, bandwidth: 850, maxCapacity: 1000, health: "healthy" },
    { id: "srv-2", name: "LB Server 1", connections: 198, bandwidth: 420, maxCapacity: 800, health: "healthy" },
    { id: "srv-3", name: "LB Server 2", connections: 120, bandwidth: 310, maxCapacity: 800, health: "warning" },
    { id: "srv-4", name: "Backup Server", connections: 0, bandwidth: 0, maxCapacity: 600, health: "offline" },
  ];

  return NextResponse.json({ servers: data });
}
