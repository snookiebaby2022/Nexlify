import { NextRequest, NextResponse } from "next/server";
import { requireSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { PanelRole, StreamHealthStatus } from "@prisma/client";

export async function GET(req: NextRequest) {
  const session = await requireSession([PanelRole.ADMIN]);
  if (!session) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { searchParams } = req.nextUrl;
  const streamId = searchParams.get("streamId");
  const status = searchParams.get("status");
  const serverId = searchParams.get("serverId");
  const limit = Math.min(Number(searchParams.get("limit") ?? 50), 200);
  const offset = Number(searchParams.get("offset") ?? 0);

  const where: Record<string, unknown> = {};
  if (streamId) where.streamId = streamId;
  if (status) where.status = status as StreamHealthStatus;
  if (serverId) where.serverId = serverId;

  const [checks, total] = await Promise.all([
    prisma.streamHealthCheck.findMany({
      where,
      orderBy: { checkedAt: "desc" },
      take: limit,
      skip: offset,
      include: {
        stream: { select: { id: true, name: true } },
        server: { select: { id: true, name: true } },
      },
    }),
    prisma.streamHealthCheck.count({ where }),
  ]);

  return NextResponse.json({ checks, total, limit, offset });
}

export async function POST(req: NextRequest) {
  const session = await requireSession([PanelRole.ADMIN]);
  if (!session) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const body = await req.json();
  const streamId = String(body.streamId ?? "");
  if (!streamId) return NextResponse.json({ error: "streamId required" }, { status: 400 });

  const status = body.status as StreamHealthStatus;
  if (!status) return NextResponse.json({ error: "status required" }, { status: 400 });

  const check = await prisma.streamHealthCheck.create({
    data: {
      streamId,
      serverId: body.serverId ? String(body.serverId) : null,
      status,
      responseTimeMs: body.responseTimeMs != null ? Number(body.responseTimeMs) : null,
      bitrateKbps: body.bitrateKbps != null ? Number(body.bitrateKbps) : null,
      audioTracks: body.audioTracks != null ? Number(body.audioTracks) : null,
      videoTracks: body.videoTracks != null ? Number(body.videoTracks) : null,
      hasAudioLoss: Boolean(body.hasAudioLoss ?? false),
      hasLoop: Boolean(body.hasLoop ?? false),
      hasFreeze: Boolean(body.hasFreeze ?? false),
      errorMessage: body.errorMessage ? String(body.errorMessage) : null,
    },
  });

  return NextResponse.json({ check });
}
