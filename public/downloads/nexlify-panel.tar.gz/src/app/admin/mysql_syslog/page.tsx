import { AdminModulePage } from "@/components/admin-module-page";

export default function Page() {
  return <AdminModulePage slug="mysql_syslog" />;
}
