import { NextResponse } from "next/server";
import { PANEL_RELEASES_FEED } from "@/lib/panel-releases-data";

/** Public release notes feed for Admin → Updates, What's new modal, and nexlify.live. */
export async function GET() {
  return NextResponse.json(PANEL_RELEASES_FEED, {
    headers: {
      "Cache-Control": "public, max-age=300",
      "Access-Control-Allow-Origin": "*",
    },
  });
}
