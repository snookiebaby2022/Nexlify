import type { NextRequest } from "next/server";

/** True when the request is an authorized internal call (not spoofable via X-Forwarded-For alone). */
export function isAuthorizedInternalRequest(req: NextRequest): boolean {
  const secret = process.env.PANEL_INTERNAL_SECRET?.trim();
  if (secret) {
    return req.headers.get("x-panel-internal-secret") === secret;
  }
  if (process.env.NODE_ENV === "production") return false;
  return !req.headers.get("x-forwarded-for") && !req.headers.get("x-real-ip");
}
